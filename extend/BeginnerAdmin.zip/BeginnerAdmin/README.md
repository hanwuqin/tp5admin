#beginner_admin
基于LayUI的管理后台模板
Layui版本 1.0.4
演示站点:http://beginner.zhengjinfan.cn/demo/beginner_admin/
交流Q群：248049395 

版本号:# v0.0.6 2016-11-27

1、添加tab组件
2、使用tab组件优化tab选项卡的代码
3、将index.html页面的js代码独立出来

版本号:# v0.0.5 2016-11-26

1、添加隐藏左侧导航栏功能
2、修改tab选项卡样式
3、添加左侧nav导航栏选中状态

版本号:# v0.0.4 2016-11-25

1、添加Navbar组件（动态渲染nav）
2、更新首页nav的渲染方式 (使用Navbar组件动态渲染)

版本号:# v0.0.3 2016-11-22

1、table 添加单选，全选功能
    1.1、依赖组件iCheck 文档地址： http://www.bootcss.com/p/icheck/
2、添加登录页面
3、top样式修改
4、修复直接选中checkbox时背景色没变化，感谢@瀮月的反馈

版本号:# v0.0.1 2016-11-20

1、基本布局 tab + iframe
2、动态添加，删除tab
3、表格样式
4、分页组件